import { GoogleGenAI, Type } from "@google/genai";
import { Workflow, Lead, LeadStage } from '../types';

// Per coding guidelines, the API key must be obtained exclusively from the environment variable.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateBusinessStrategy = async (workflow: Workflow, clientDescription: string): Promise<string> => {
    
    const prompt = `
    As an expert n8n automation consultant and business strategist, analyze the following workflow and generate a proposal for a potential client.

    **Workflow Details:**
    - **Name:** ${workflow.title}
    - **Category:** ${workflow.category}

    **Potential Client:**
    - **Description:** ${clientDescription || 'A general small to medium-sized business'}

    **Your Task:**
    Generate a comprehensive analysis and proposal. Structure your response in Markdown with the following sections:

    ### 🚀 Workflow Explanation
    Briefly explain what this workflow does in simple, clear terms.

    ### 📈 Key Business Benefits
    List 3-5 key benefits this workflow would provide for the specified client. Be specific and results-oriented (e.g., "Increase lead conversion by X%", "Save Y hours per week").

    ### 💰 Monetization Strategies
    Suggest 2-3 ways I can sell this workflow as a service or product. For example:
    1.  **One-Time Setup Fee:** A flat rate to implement the workflow.
    2.  **Monthly Retainer:** For ongoing management, support, and optimization.
    3.  **Productized Service:** Sell the pre-built workflow as a package.

    ### 🛠️ High-Level Implementation Steps
    Provide a concise, step-by-step plan to implement this for the client.

    ### 💬 Sample Pitch
    Write a short, compelling email or message to pitch this automation service to the client.

    **Instructions:**
    - Use clear headings and bullet points.
    - Be professional, concise, and action-oriented.
    `;
  
  try {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    return "An error occurred while generating the business strategy. Please check your API key and network connection.";
  }
};

export const suggestNextLeadStage = async (lead: Lead): Promise<LeadStage> => {
    const chatHistoryText = lead.chatHistory.map(m => `${m.isUser ? 'Client' : 'Assistant'}: ${m.text}`).join('\n');

    const prompt = `
        As a sales manager, analyze the following lead and their conversation history to suggest the next logical stage in the sales pipeline.

        **Lead Information:**
        - Name: ${lead.name}
        - Company: ${lead.company}
        - Initial Search Term: ${lead.searchTerm}

        **Conversation History:**
        ${chatHistoryText}

        **Current Stage:** ${lead.stage}

        **Available Stages:**
        - 'Caixa de Entrada': New lead, not yet reviewed.
        - 'Qualificação': Actively in conversation, discovery phase.
        - 'Oportunidade': A clear need and potential solution have been identified. A proposal is likely the next step.
        - 'Cliente (Ganho)': The deal is won.
        - 'Perdido': The lead is not a good fit or has chosen another solution.

        **Your Task:**
        Based on the conversation, what is the SINGLE most appropriate next stage for this lead?
        - If the assistant has just finished collecting contact info and the client agreed to a call, the next stage should be 'Qualificação'.
        - If the conversation identified a clear, quantifiable problem and the client is eager for a solution, the stage should be 'Oportunidade'.
        - If the client said "no thanks" or seems like a bad fit, the stage should be 'Perdido'.
        - If the client is brand new, it should be 'Caixa de Entrada'.
        
        Respond ONLY with the name of the suggested stage from the available list. For example: Oportunidade
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        const suggestedStage = response.text.trim();
        const validStages: LeadStage[] = ['Caixa de Entrada', 'Qualificação', 'Oportunidade', 'Cliente (Ganho)', 'Perdido'];
        if (validStages.includes(suggestedStage as LeadStage)) {
            return suggestedStage as LeadStage;
        }
        return lead.stage; // Return current stage if suggestion is invalid
    } catch (error) {
        console.error("Error suggesting next lead stage:", error);
        return lead.stage; // Return current stage on error
    }
};

const assistantSystemInstructions: Record<string, string> = {
    'crm-strategist': `You are a world-class CRM and Business Automation strategist. Your core philosophy is based on the "Narrative Ladder" framework. You believe traditional, monolithic CRMs are obsolete because they create data silos and lock users into a closed ecosystem. Your mission is to advocate for a modern, open, and integrated approach.

    **Your Narrative Ladder:**
    - **The Shift:** The world now runs on dozens of specialized apps (Slack, Meta, Google Ads, etc.), not one single software. Customer data is scattered.
    - **The Challenge:** Monolithic CRMs try to replace these tools, creating a "walled garden" that is rigid, expensive, and poorly adopted. Data becomes a hostage.
    - **The Impact:** This leads to disconnected data, manual copy-pasting, missed opportunities, and a fragmented view of the customer.
    - **The Solution:** A "Smart Hub" built on open-source technology (like n8n) that *unifies* existing tools instead of replacing them. It creates a central nervous system for the business.
    - **The Difference:** This approach is flexible, cost-effective, and ensures the client **owns their data and processes forever.** No vendor lock-in.

    When a user asks for copy, a strategy, or an explanation, you must use this narrative. Frame your answers around the concepts of unification, open-source freedom, and owning your own data. Challenge the idea of a single, closed-off CRM. Always be strategic, insightful, and persuasive.`,
    'sales-copywriter': `You are a world-class direct response copywriter and sales strategist, trained in the principles of Challenger Sale, Sandler, and Eugene Schwartz. Your goal is to write compelling, persuasive copy that addresses deep customer pain points, challenges their assumptions, and guides them towards a solution. Always focus on benefits over features, use clear and concise language, and end with a strong call to action. When asked for ideas, provide specific, actionable examples.`,
    'content-strategist': `You are a creative and data-driven B2B content strategist. Your expertise is in creating content that builds authority, educates the target audience, and generates qualified leads for technology and consulting services. When a user asks for ideas, provide them with headline suggestions, key talking points for a blog post or video, and a promotional snippet for social media. Your tone should be knowledgeable, helpful, and professional.`,
    'business-consultant': `You are a seasoned business consultant specializing in operational efficiency and automation for small to medium-sized businesses. You think in terms of systems, processes, and ROI. When a user presents a problem, your task is to break it down, identify the root cause, and propose a solution that involves automation. Provide high-level implementation steps and potential metrics to track success.`,
    'general-assistant': `You are a helpful and versatile AI assistant. Your goal is to provide clear, accurate, and concise answers to the user's questions on a wide range of topics.`,
};


export const generateAssistantResponse = async (userPrompt: string, assistantType: string, dataContext?: string): Promise<string> => {
    const systemInstruction = assistantSystemInstructions[assistantType] || assistantSystemInstructions['general-assistant'];

    const finalPrompt = dataContext
        ? `Based on the following data, please answer the user's question.
---
DATA:
${dataContext}
---
USER QUESTION: ${userPrompt}`
        : userPrompt;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-pro', // Using a more powerful model for nuanced assistant tasks
            contents: finalPrompt,
            config: {
                systemInstruction: systemInstruction,
            }
        });
        return response.text;
    } catch (error) {
        console.error("Error calling Gemini API for assistant:", error);
        return "An error occurred while generating the assistant response. Please try again later.";
    }
};

export const generateLeadScore = async (lead: Omit<Lead, 'id' | 'capturedAt' | 'stage' | 'landingPageVersion' | 'score' | 'scoreReason' | 'isScoring'>): Promise<{ score: number; reason: string; }> => {
    const chatHistoryText = lead.chatHistory.map(m => `${m.isUser ? 'Client' : 'Assistant'}: ${m.text}`).join('\n');
    
    const prompt = `
        Analyze the following sales lead and generate a lead score from 0 to 100.
        
        **Lead Information:**
        - Name: ${lead.name}
        - Company: ${lead.company}
        - Search Term Used: "${lead.searchTerm}"
        - Full Conversation Transcript:
        ${chatHistoryText}

        **Scoring Criteria:**
        1.  **Search Term Intent (Weight: 40%):** How closely does the search term match high-value services?
            - High Score Keywords: "consultoria automação", "n8n specialist", "automatizar processos", "hubspot alternative".
            - Medium Score Keywords: "marketing digital", "crm para pmes".
            - Low Score Keywords: "curso de marketing", "ferramentas gratuitas".
            - "Direct Traffic / Unknown" should be scored moderately, relying more on the chat.
        2.  **Engagement & Urgency (Weight: 60%):** How engaged and ready-to-act was the prospect in the chat?
            - High Score Indicators: Acknowledged a clear pain point (e.g., "é exatamente isso!"), asked clarifying questions ("Como isso funciona?"), quickly agreed to a call.
            - Low Score Indicators: Hesitant responses ("Não tenho certeza."), chose "Não, obrigado(a)", generic answers.

        **Output Format:**
        You must respond with a JSON object containing two keys: "score" (a number between 0 and 100) and "reason" (a short, one-sentence explanation for the score).
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        score: { type: Type.NUMBER },
                        reason: { type: Type.STRING }
                    },
                    required: ["score", "reason"]
                }
            }
        });
        
        const jsonText = response.text.trim();
        const result = JSON.parse(jsonText);

        if (typeof result.score === 'number' && typeof result.reason === 'string') {
            return result;
        }
        
        throw new Error("Invalid JSON structure from Gemini.");

    } catch (error) {
        console.error("Error generating lead score:", error);
        return { score: 0, reason: "An error occurred during scoring." };
    }
};
