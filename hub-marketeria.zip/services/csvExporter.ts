// This service provides functionality to export a pre-configured Google Ads campaign as a CSV file.

const campaignData = [
    {
        Campaign: 'Marketeria - Search - Automation Services',
        'Ad group': 'Automation Consulting',
        'Keyword type': 'Phrase',
        Keyword: '"consultoria de automação para empresas"',
        'Headline 1': 'Automação para Empresas',
        'Headline 2': 'Marketeria | Libere Seu Tempo',
        'Headline 3': 'Diagnóstico Gratuito',
        'Description 1': 'Automatizamos tarefas manuais para você focar no crescimento. Reduza custos e aumente a eficiência.',
        'Description 2': 'Agende sua análise estratégica gratuita e descubra o potencial da automação no seu negócio.',
    },
    {
        Campaign: 'Marketeria - Search - Automation Services',
        'Ad group': 'Automation Consulting',
        'Keyword type': 'Phrase',
        Keyword: '"especialista em automação de processos"',
        'Headline 1': 'Especialistas em Automação',
        'Headline 2': 'Otimize Seus Processos',
        'Headline 3': 'Fale com um Consultor',
        'Description 1': 'Transforme suas operações com automação inteligente. Aumente a produtividade e reduza erros.',
        'Description 2': 'Receba um plano de ação personalizado para o seu negócio. Agende uma chamada sem compromisso.',
    },
    {
        Campaign: 'Marketeria - Search - Automation Services',
        'Ad group': 'Automation Consulting',
        'Keyword type': 'Phrase',
        Keyword: '"automatizar marketing para agências"',
        'Headline 1': 'Automação para Agências',
        'Headline 2': 'Relatórios e Leads no Piloto Auto',
        'Headline 3': 'Escale Seus Serviços',
        'Description 1': 'Entregue relatórios, capture leads e gerencie campanhas de forma 100% automatizada.',
        'Description 2': 'Ofereça mais valor aos seus clientes sem aumentar sua equipe. Veja como funciona.',
    },
    {
        Campaign: 'Marketeria - Search - Automation Services',
        'Ad group': 'Automation Consulting',
        'Keyword type': 'Broad',
        Keyword: 'serviços de automação n8n',
        'Headline 1': 'Consultoria n8n Oficial',
        'Headline 2': 'Implementamos Seus Fluxos',
        'Headline 3': 'Soluções Personalizadas',
        'Description 1': 'Aproveite todo o poder do n8n com a ajuda de especialistas. Criamos e gerenciamos suas automações.',
        'Description 2': 'Deixe a complexidade conosco e foque no seu core business. Peça um orçamento.',
    }
];

const convertToCSV = (data: object[]): string => {
    const headers = Object.keys(data[0]);
    const rows = data.map(obj => 
        headers.map(header => {
            const value = obj[header as keyof typeof obj] || '';
            const escaped = ('' + value).replace(/"/g, '""');
            return `"${escaped}"`;
        }).join(',')
    );
    return [headers.join(','), ...rows].join('\n');
};

export const exportGoogleAdsCampaign = () => {
    const csvContent = convertToCSV(campaignData);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', 'google_ads_campaign_marketeria.csv');
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
};
