import React from 'react';
import { IconProps } from './Icon';

const PresentationChartLineIcon: React.FC<IconProps> = ({ className = 'w-6 h-6' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 13v-1m4 1v-3m4 3V8M5.884 14.116a3 3 0 11-4.243-4.243 3 3 0 014.243 4.243zM11 5.884a3 3 0 11-4.243-4.243 3 3 0 014.243 4.243zM16.116 14.116a3 3 0 11-4.243-4.243 3 3 0 014.243 4.243zM11 16.116a3 3 0 11-4.243-4.243 3 3 0 014.243 4.243z" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-5" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3l18 18" />
    </svg>
);

export default PresentationChartLineIcon;
