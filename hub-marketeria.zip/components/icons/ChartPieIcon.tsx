import React from 'react';
import { IconProps } from './Icon';

const ChartPieIcon: React.FC<IconProps> = ({ className = 'w-6 h-6' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 6a7.5 7.5 0 100 15 7.5 7.5 0 000-15z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M21 10.5c0 4.142-3.358 7.5-7.5 7.5V10.5h7.5z" />
    </svg>
);

export default ChartPieIcon;
