
import React from 'react';
import { IconProps } from './Icon';

const SparklesIcon: React.FC<IconProps> = ({ className = 'w-6 h-6' }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M16 17v4m-2-2h4M19 12a7 7 0 11-14 0 7 7 0 0114 0z" />
    </svg>
);

export default SparklesIcon;
