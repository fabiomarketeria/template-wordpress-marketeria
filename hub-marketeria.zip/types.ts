export interface Workflow {
  emoji: string;
  title: string;
  category: string;
}

export interface Bonus {
  emoji: string;
  title: string;
  description: string;
}

export type View = 'dashboard' | 'workflows' | 'bonuses' | 'useCases' | 'strategy' | 'landingPage' | 'metricsDashboard' | 'chat' | 'funnelDashboard' | 'promptLibrary' | 'leads' | 'brandKit' | 'analyticsDashboard' | 'consultingPage';

export interface MonetizationOption {
  id: string;
  type: 'one-time' | 'retainer' | 'productized' | 'custom';
  price: string;
  description: string;
}

export interface ChatMessage {
  text: string;
  isUser: boolean;
}

export type LeadStage = 'Caixa de Entrada' | 'Qualificação' | 'Oportunidade' | 'Cliente (Ganho)' | 'Perdido';

export interface Lead {
  id: string;
  name: string;
  email: string;
  company: string;
  capturedAt: string;
  searchTerm: string;
  chatHistory: ChatMessage[];
  stage: LeadStage;
  landingPageVersion?: 'A' | 'B';
  score?: number;
  scoreReason?: string;
  isScoring?: boolean;
  value?: number;
  closedAt?: string;
}