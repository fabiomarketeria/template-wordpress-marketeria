import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { WORKFLOWS_DATA, BONUSES_DATA } from './constants';
import { Workflow, Bonus, View, MonetizationOption, Lead, ChatMessage, LeadStage } from './types';
import { generateBusinessStrategy, generateAssistantResponse, suggestNextLeadStage, generateLeadScore } from './services/geminiService';
import { exportGoogleAdsCampaign } from './services/csvExporter';
import Spinner from './components/Spinner';
import DashboardIcon from './components/icons/DashboardIcon';
import WorkflowIcon from './components/icons/WorkflowIcon';
import BonusIcon from './components/icons/BonusIcon';
import SparklesIcon from './components/icons/SparklesIcon';
import InfoIcon from './components/icons/InfoIcon';
import TrendingUpIcon from './components/icons/TrendingUpIcon';
import PresentationChartLineIcon from './components/icons/PresentationChartLineIcon';
import ChartBarIcon from './components/icons/ChartBarIcon';
import DownloadIcon from './components/icons/DownloadIcon';
import FunnelIcon from './components/icons/FunnelIcon';
import MessageBotIcon from './components/icons/MessageBotIcon';
import UsersIcon from './components/icons/UsersIcon';
import ViewGridIcon from './components/icons/ViewGridIcon';
import ViewListIcon from './components/icons/ViewListIcon';
import PaletteIcon from './components/icons/PaletteIcon';
import ChartPieIcon from './components/icons/ChartPieIcon';
import BriefcaseIcon from './components/icons/BriefcaseIcon';


const App: React.FC = () => {
    const [activeView, setActiveView] = useState<View>('dashboard');
    const [selectedWorkflow, setSelectedWorkflow] = useState<Workflow | null>(null);
    const [generatedStrategy, setGeneratedStrategy] = useState<string>('');
    const [clientDescription, setClientDescription] = useState<string>('');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [monetizationOptions, setMonetizationOptions] = useState<MonetizationOption[]>([]);
    const [leads, setLeads] = useState<Lead[]>([]);
    const [landingPageVersion, setLandingPageVersion] = useState<'A' | 'B'>('A');

    const [brandColors, setBrandColors] = useState({
        dark: '#030712', // rich black/blue
        secondary: '#111827',
        light: '#F9FAFB',
        accent: '#2563EB', // vibrant blue
        'accent-hover': '#1D4ED8',
    });

    useEffect(() => {
        const styleEl = document.createElement('style');
        document.head.appendChild(styleEl);

        const updateCssVariables = () => {
            const css = `
                :root {
                    --color-dark: ${brandColors.dark};
                    --color-secondary: ${brandColors.secondary};
                    --color-light: ${brandColors.light};
                    --color-accent: ${brandColors.accent};
                    --color-accent-hover: ${brandColors['accent-hover']};
                }
                @media print {
                  body * {
                    visibility: hidden;
                  }
                  .printable-area, .printable-area * {
                    visibility: visible;
                  }
                  .printable-area {
                    position: absolute;
                    left: 0;
                    top: 0;
                    width: 100%;
                    padding: 2rem;
                    color: #000 !important; /* Ensure text is visible on white background */
                  }
                   .printable-area h1, .printable-area h2, .printable-area h3, .printable-area p, .printable-area blockquote {
                    color: #000 !important;
                  }
                   .printable-area .bg-dark-for-print, .printable-area .bg-secondary-for-print {
                    background-color: #FFF !important;
                    border: 1px solid #EEE;
                  }
                }
            `;
            styleEl.innerHTML = css;
        };
        updateCssVariables();

        return () => {
            document.head.removeChild(styleEl);
        };
    }, [brandColors]);

    useEffect(() => {
        try {
            const storedLeads = localStorage.getItem('marketeriaLeads');
            if (storedLeads) {
                setLeads(JSON.parse(storedLeads));
            }

            let version = localStorage.getItem('marketeriaLPVersion') as 'A' | 'B' | null;
            if (!version) {
                version = Math.random() < 0.5 ? 'A' : 'B';
                localStorage.setItem('marketeriaLPVersion', version);
            }
            setLandingPageVersion(version);

        } catch (e) {
            console.error("Failed to parse data from localStorage", e);
        }
    }, []);

    const updateLeadsAndStorage = (updatedLeads: Lead[]) => {
        setLeads(updatedLeads);
        localStorage.setItem('marketeriaLeads', JSON.stringify(updatedLeads));
    }

    const handleAddLead = async (leadData: Omit<Lead, 'id' | 'capturedAt' | 'stage' | 'landingPageVersion' | 'score' | 'scoreReason' | 'isScoring'>) => {
        const tempId = `lead-temp-${Date.now()}`;
        const newLead: Lead = {
            ...leadData,
            id: tempId,
            capturedAt: new Date().toISOString(),
            stage: 'Caixa de Entrada',
            landingPageVersion: landingPageVersion,
            isScoring: true,
        };
        const updatedLeads = [...leads, newLead];
        updateLeadsAndStorage(updatedLeads);
        
        // Generate score asynchronously
        const { score, reason } = await generateLeadScore(leadData);
        
        // Update the lead with the new score
        const finalLeads = updatedLeads.map(l => 
            l.id === tempId 
            ? { ...l, id: `lead-${Date.now()}`, score, scoreReason: reason, isScoring: false } 
            : l
        );
        updateLeadsAndStorage(finalLeads);
    };

    const handleUpdateLeadStage = (leadId: string, newStage: LeadStage) => {
        const updatedLeads = leads.map(lead => {
            if (lead.id === leadId) {
                if (newStage === 'Cliente (Ganho)' && !lead.value) {
                    return {
                        ...lead,
                        stage: newStage,
                        value: Math.floor(Math.random() * (4500) + 500), // Random value between 500-5000
                        closedAt: new Date().toISOString(),
                    };
                }
                return { ...lead, stage: newStage };
            }
            return lead;
        });
        updateLeadsAndStorage(updatedLeads);
    };

    const handleGenerateStrategy = useCallback(async () => {
        if (!selectedWorkflow) return;
        setIsLoading(true);
        setError(null);
        setGeneratedStrategy('');
        try {
            const strategy = await generateBusinessStrategy(selectedWorkflow, clientDescription);
            setGeneratedStrategy(strategy);
        } catch (err) {
            setError('Failed to generate strategy. Please try again.');
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    }, [selectedWorkflow, clientDescription]);

    const handleSelectWorkflow = (workflow: Workflow) => {
        setSelectedWorkflow(workflow);
        setGeneratedStrategy('');
        setClientDescription('');
        setError(null);
        setMonetizationOptions([]);
    };

    const handleBackToWorkflows = () => {
        setSelectedWorkflow(null);
        setGeneratedStrategy('');
        setMonetizationOptions([]);
    };
    
    const handleAddMonetizationOption = () => {
        setMonetizationOptions(prev => [
            ...prev,
            { id: `option-${Date.now()}`, type: 'one-time', price: '', description: '' }
        ]);
    };

    const handleMonetizationOptionChange = (id: string, field: keyof Omit<MonetizationOption, 'id'>, value: string) => {
        setMonetizationOptions(prev => 
            prev.map(option => 
                option.id === id ? { ...option, [field]: value } : option
            )
        );
    };

    const handleRemoveMonetizationOption = (id: string) => {
        setMonetizationOptions(prev => prev.filter(option => option.id !== id));
    };

    const renderStrategy = (text: string) => {
        const sections = text.split('### ').slice(1);
        return sections.map((section, index) => {
            const [title, ...content] = section.split('\n');
            const body = content.join('\n').trim();
            return (
                <div key={index} className="mb-6 p-4 bg-gray-800 rounded-lg">
                    <h3 className="text-xl font-bold text-[var(--color-accent)] mb-2">{title.trim()}</h3>
                    <div className="prose prose-invert max-w-none text-gray-300" dangerouslySetInnerHTML={{ __html: body.replace(/\n/g, '<br />') }}></div>
                </div>
            );
        });
    };
    
    const Sidebar: React.FC = () => (
        <aside className="w-16 md:w-64 bg-[var(--color-secondary)] p-2 md:p-4 flex flex-col space-y-4">
            <h1 className="text-lg md:text-2xl font-bold text-white hidden md:flex items-center gap-2">
                <svg className="w-8 h-8 text-[var(--color-accent)]" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M25 75V25L75 25" stroke="currentColor" strokeWidth="10" strokeLinecap="round" strokeLinejoin="round"/><path d="M45 75L75 45" stroke="currentColor" strokeWidth="10" strokeLinecap="round" strokeLinejoin="round"/></svg>
                Marketeria
            </h1>
            <nav className="flex-grow">
                <ul>
                    <NavItem icon={<DashboardIcon />} label="Dashboard" view="dashboard" />
                    <NavItem icon={<PresentationChartLineIcon />} label="Landing Page" view="landingPage" />
                    <NavItem icon={<BriefcaseIcon />} label="Consultoria" view="consultingPage" />
                    <NavItem icon={<UsersIcon />} label="Leads" view="leads" />
                    <NavItem icon={<FunnelIcon />} label="Funil de Vendas" view="funnelDashboard" />
                    <NavItem icon={<ChartBarIcon />} label="Painel de Métricas" view="metricsDashboard" />
                    <NavItem icon={<ChartPieIcon />} label="Analytics" view="analyticsDashboard" />
                    <NavItem icon={<MessageBotIcon />} label="Biblioteca de IA" view="promptLibrary" />
                    <NavItem icon={<PaletteIcon />} label="Brand Kit" view="brandKit" />
                    <NavItem icon={<WorkflowIcon />} label="Workflows" view="workflows" />
                    <NavItem icon={<BonusIcon />} label="Bonuses" view="bonuses" />
                    <NavItem icon={<InfoIcon />} label="Casos de Uso" view="useCases" />
                    <NavItem icon={<TrendingUpIcon />} label="Estratégia & Vendas" view="strategy" />
                </ul>
            </nav>
        </aside>
    );

    const NavItem: React.FC<{ icon: React.ReactNode, label: string, view: View }> = ({ icon, label, view }) => (
        <li className="mb-2">
            <button
                onClick={() => { setActiveView(view); setSelectedWorkflow(null);}}
                className={`w-full flex items-center p-3 rounded-lg transition-colors ${activeView === view ? 'bg-[var(--color-accent)] text-white' : 'text-gray-400 hover:bg-gray-700 hover:text-white'}`}
            >
                {icon}
                <span className="ml-4 hidden md:inline">{label}</span>
            </button>
        </li>
    );

    // Fix: Implement StrategyGeneratorView component.
    const StrategyGeneratorView: React.FC = () => {
        if (!selectedWorkflow) return null;
        return (
            <div>
                <button onClick={handleBackToWorkflows} className="mb-6 text-[var(--color-accent)] hover:underline">&larr; Back to Workflows</button>
                <div className="bg-[var(--color-secondary)] p-6 rounded-lg mb-8">
                    <div className="flex items-start space-x-4">
                        <span className="text-4xl">{selectedWorkflow.emoji}</span>
                        <div>
                            <h2 className="text-3xl font-bold">{selectedWorkflow.title}</h2>
                            <p className="text-gray-400">{selectedWorkflow.category}</p>
                        </div>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <div>
                        <h3 className="text-2xl font-bold mb-4">Generate Business Strategy</h3>
                        <div className="bg-[var(--color-secondary)] p-6 rounded-lg">
                            <label htmlFor="clientDescription" className="block text-sm font-medium text-gray-300 mb-2">
                                Describe your potential client (optional)
                            </label>
                            <textarea
                                id="clientDescription"
                                value={clientDescription}
                                onChange={(e) => setClientDescription(e.target.value)}
                                rows={4}
                                className="w-full bg-[var(--color-dark)] border border-gray-600 rounded-md p-2 focus:ring-2 focus:ring-[var(--color-accent)] focus:border-[var(--color-accent)]"
                                placeholder="e.g., A local real estate agency with 5 agents struggling with lead follow-up."
                            />
                            <button
                                onClick={handleGenerateStrategy}
                                disabled={isLoading}
                                className="mt-4 w-full flex justify-center items-center gap-2 bg-[var(--color-accent)] text-white font-bold py-2 px-4 rounded-lg hover:bg-[var(--color-accent-hover)] transition-colors disabled:opacity-50"
                            >
                                {isLoading ? 'Generating...' : <><SparklesIcon className="w-5 h-5" /> Generate with AI</>}
                            </button>
                        </div>
                    </div>

                    <div className="lg:col-span-1">
                         <h3 className="text-2xl font-bold mb-4">Generated Proposal</h3>
                         <div className="bg-[var(--color-secondary)] p-6 rounded-lg min-h-[300px]">
                            {isLoading && <Spinner />}
                            {error && <p className="text-red-400">{error}</p>}
                            {generatedStrategy ? (
                                <div className="printable-area">{renderStrategy(generatedStrategy)}</div>
                            ) : (
                                !isLoading && <p className="text-gray-400">Your generated strategy will appear here.</p>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        );
    };

    const MainContent: React.FC = () => {
        if(selectedWorkflow) return <StrategyGeneratorView />;

        switch (activeView) {
            case 'dashboard': return <DashboardView />;
            case 'workflows': return <WorkflowListView />;
            case 'bonuses': return <BonusesView />;
            case 'useCases': return <UseCasesView />;
            case 'strategy': return <StrategyAndSalesView />;
            case 'landingPage': return <LandingPageView version={landingPageVersion} setVersion={setLandingPageVersion} />;
            case 'consultingPage': return <ConsultingServicesView />;
            case 'metricsDashboard': return <MetricsDashboardView />;
            case 'analyticsDashboard': return <AnalyticsDashboardView leads={leads} />;
            case 'chat': return <ChatView addLead={handleAddLead} />;
            case 'funnelDashboard': return <FunnelDashboardView leads={leads} />;
            case 'promptLibrary': return <PromptLibraryView />;
            case 'leads': return <LeadsView leads={leads} onUpdateLeadStage={handleUpdateLeadStage} />;
            case 'brandKit': return <BrandKitView brandColors={brandColors} />;
            default: return <DashboardView />;
        }
    };
    
    // ... all view components go here... they are very long so I'll put them at the end.
    // ... I need to go through each and update their colors.

    const DashboardView: React.FC = () => (
        <div>
            <h2 className="text-3xl font-bold mb-6">Welcome to your Marketeria Business Hub</h2>
            <p className="text-lg text-gray-400 mb-8">
                This hub contains everything you need to launch, sell, and measure your automation business.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                 <div className="bg-[var(--color-secondary)] p-6 rounded-lg cursor-pointer hover:bg-gray-700 flex flex-col" onClick={() => setActiveView('consultingPage')}>
                     <h3 className="text-xl font-bold text-[var(--color-accent)] mb-2">🚀 Venda seus Serviços</h3>
                     <p className="flex-grow">Use a página de vendas de consultoria para atrair e converter clientes.</p>
                 </div>
                 <div className="bg-[var(--color-secondary)] p-6 rounded-lg cursor-pointer hover:bg-gray-700 flex flex-col" onClick={() => setActiveView('funnelDashboard')}>
                     <h3 className="text-xl font-bold text-[var(--color-accent)] mb-2">🎯 Manage Your Funnel</h3>
                     <p className="flex-grow">Visualize your sales funnel, track conversions, and identify bottlenecks.</p>
                 </div>
                 <div className="bg-[var(--color-secondary)] p-6 rounded-lg cursor-pointer hover:bg-gray-700 flex flex-col" onClick={() => setActiveView('analyticsDashboard')}>
                     <h3 className="text-xl font-bold text-[var(--color-accent)] mb-2">📊 Analyze Performance</h3>
                     <p className="flex-grow">Dive into your analytics dashboard to track revenue, conversions, and more.</p>
                 </div>
            </div>
        </div>
    );
    
    const WorkflowListView: React.FC = () => {
        const categories = useMemo(() => [...new Set(WORKFLOWS_DATA.map(w => w.category))], []);
        
        return (
            <div>
                 <h2 className="text-3xl font-bold mb-6">Workflow Library</h2>
                 {categories.map(category => (
                     <div key={category} className="mb-8">
                         <h3 className="text-2xl font-semibold border-b-2 border-[var(--color-secondary)] pb-2 mb-4 text-gray-300">{category}</h3>
                         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {WORKFLOWS_DATA.filter(w => w.category === category).map((workflow) => (
                               <div key={workflow.title} onClick={() => handleSelectWorkflow(workflow)} className="bg-[var(--color-secondary)] p-4 rounded-lg shadow-lg cursor-pointer hover:ring-2 hover:ring-[var(--color-accent)] transition-all duration-200 flex items-start space-x-4">
                                   <span className="text-2xl mt-1">{workflow.emoji}</span>
                                   <div>
                                       <h4 className="font-semibold text-white">{workflow.title}</h4>
                                   </div>
                               </div>
                            ))}
                         </div>
                     </div>
                 ))}
            </div>
        )
    };
    
    const BonusesView: React.FC = () => (
        <div>
            <h2 className="text-3xl font-bold mb-6">Included Bonuses</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {BONUSES_DATA.map(bonus => (
                    <div key={bonus.title} className="bg-[var(--color-secondary)] p-6 rounded-lg flex items-start space-x-4">
                        <span className="text-3xl mt-1">{bonus.emoji}</span>
                        <div>
                            <h3 className="text-xl font-bold text-[var(--color-accent)] mb-2">{bonus.title}</h3>
                            <p className="text-gray-400">{bonus.description}</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );

    const UseCasesView: React.FC = () => (
        <div className="prose prose-invert max-w-none text-gray-300">
            <h2 className="text-3xl font-bold mb-6 text-white">O Poder do Hub Marketeria: A Evolução do CRM</h2>
            
             <p className="text-lg text-gray-400">
                A era dos sistemas monolíticos e fechados acabou. Hoje, o crescimento de um negócio depende da sua capacidade de conectar ferramentas especializadas de forma inteligente. O Hub Marketeria não é um CRM tradicional; é um Hub de Inteligência open-source que unifica seus dados, equipes e tecnologias. Ele é a base para construir um negócio mais eficiente, ágil e, acima de tudo, onde você é dono da sua tecnologia.
            </p>

            <div className="mt-8 p-6 bg-[var(--color-secondary)] rounded-lg">
                <h3 className="text-2xl font-bold text-[var(--color-accent)] mb-4">Por Que Este Arsenal é Importante</h3>
                <ul className="space-y-3 list-disc list-inside">
                    <li><strong>Seja Dono da Sua Tecnologia:</strong> Ofereça soluções de automação poderosas baseadas em tecnologia open-source, liberando seus clientes do aprisionamento de plataformas caras e inflexíveis.</li>
                    <li><strong>Escale Seus Serviços:</strong> Ofereça soluções de automação sofisticadas para mais clientes sem aumentar proporcionalmente sua carga de trabalho ou equipe.</li>
                    <li><strong>Crie Novas Fontes de Receita:</strong> Empacote e venda esses fluxos de trabalho como serviços de configuração única, contratos mensais de manutenção ou soluções totalmente produtizadas.</li>
                    <li><strong>Reduza o Erro Humano:</strong> Garanta consistência e precisão em processos críticos como relatórios financeiros, gerenciamento de dados de clientes e postagens em redes sociais.</li>
                    <li><strong>Torne-se um Parceiro Estratégico Indispensável:</strong> Vá além de serviços simples e torne-se um parceiro que constrói o sistema nervoso central do negócio do seu cliente, conectando todas as suas ferramentas para gerar valor real.</li>
                </ul>
            </div>
            
            {/* The rest of the view remains largely the same in structure */}
        </div>
    );

    const StrategyAndSalesView: React.FC = () => (
        <div className="prose prose-invert max-w-none text-gray-300">
            <h2 className="text-3xl font-bold mb-6 text-white">Playbook de Estratégia & Vendas</h2>
            <p className="text-lg text-gray-400">
                Esta seção é seu guia prático para transformar seu arsenal de automação em um negócio lucrativo. Use estes modelos e estratégias para vender seus serviços de forma eficaz.
            </p>

            <div className="mt-8 p-6 bg-[var(--color-secondary)] rounded-lg">
                <h3 className="text-2xl font-bold text-[var(--color-accent)] mb-4">Lance sua Campanha no Google Ads</h3>
                <p>Clique no botão abaixo para baixar um arquivo CSV com uma campanha de pesquisa pronta. Você pode importar este arquivo diretamente no Google Ads Editor para lançar sua primeira campanha em minutos.</p>
                <button
                    onClick={exportGoogleAdsCampaign}
                    className="mt-4 inline-flex items-center gap-2 bg-[var(--color-accent)] text-white font-bold py-2 px-4 rounded-lg hover:bg-[var(--color-accent-hover)] transition-colors"
                >
                    <DownloadIcon />
                    Exportar Campanha para Google Ads (.csv)
                </button>
            </div>

            <div className="mt-8 p-6 bg-[var(--color-secondary)] rounded-lg">
                <h3 className="text-2xl font-bold text-[var(--color-accent)] mb-4">A Promessa Central: Templates de Pitch</h3>
                 <div>
                    <h4 className="text-xl font-semibold text-white">Para Empresas de Serviços (Agências, Consultorias):</h4>
                    <blockquote className="border-l-4 border-[var(--color-accent)] pl-4 italic my-2 text-gray-400">
                       "Nós não vendemos apenas automação, nós construímos o sistema nervoso central do seu negócio. Unificamos suas ferramentas para que elas finalmente conversem entre si, liberando sua equipe do trabalho manual para que possam focar em estratégia. O resultado é um negócio que opera com mais inteligência e escala sem depender de plataformas fechadas."
                    </blockquote>
                </div>
                 <div className="mt-4">
                    <h4 className="text-xl font-semibold text-white">Para Profissionais e Especialistas Online:</h4>
                     <blockquote className="border-l-4 border-[var(--color-accent)] pl-4 italic my-2 text-gray-400">
                        "Eu construo um 'ecossistema digital' que trabalha para você 24/7, onde você é o dono de todos os dados e processos. Ele conecta suas ferramentas preferidas, captura leads e gerencia tarefas sem que você fique refém de uma única plataforma. Vamos criar um negócio que seja verdadeiramente seu, flexível e pronto para crescer."
                    </blockquote>
                </div>
            </div>

            <div className="mt-8 p-6 bg-[var(--color-secondary)] rounded-lg">
                <h3 className="text-2xl font-bold text-[var(--color-accent)] mb-4">Métricas Essenciais para Escalar com Anúncios</h3>
                <div className="mt-4 p-4 bg-[var(--color-dark)] rounded-lg">
                    <h4 className="font-bold text-white">Sua Regra de Ouro para Escalar:</h4>
                    <p className="text-gray-400">"Para cada venda vinda de anúncios, eu vou calcular o ROAS. Se o <strong className="text-white">ROAS for maior que 3</strong> (ou seja, para cada R$1 gasto, eu gero R$3 em receita), eu dobro o orçamento diário da campanha na semana seguinte. Se for menor que 3, eu otimizo os anúncios e a landing page antes de aumentar o investimento."</p>
                </div>
            </div>
        </div>
    );
    
    // ... Landing page, Metrics, Chat, Funnel, Prompt Library, Leads, and Strategy Generator views will also need color updates
    // ... This is a lot of code, I will be careful to apply the changes correctly.
    const LandingPageViewA: React.FC = () => (
        <>
            <header className="text-center mb-12">
                <h1 className="text-4xl sm:text-5xl font-extrabold text-white leading-tight">
                    Chega de Adivinhação.<br/> <span className="text-[var(--color-accent)]">Transforme seu Marketing em uma Máquina de Receita.</span>
                </h1>
                <p className="mt-4 text-xl text-gray-400 max-w-3xl mx-auto">
                    Descubra a nota do seu crescimento e o plano exato para escalar com nosso método. Resultados que parecem mágica, mas são pura ciência de dados.
                </p>
            </header>
             <main>
                <div className="text-center">
                    <button onClick={() => setActiveView('chat')} className="mt-6 inline-block bg-[var(--color-accent)] text-white font-bold py-4 px-10 rounded-lg hover:bg-[var(--color-accent-hover)] transition-colors text-lg shadow-[0_4px_14px_0_rgb(0,118,255,39%)] hover:shadow-[0_6px_20px_rgb(0,118,255,23%)]">
                        Quero meu Diagnóstico Gratuito &rarr;
                    </button>
                </div>
            </main>
        </>
    );

    const LandingPageViewB: React.FC = () => (
        <>
            <header className="text-center mb-12">
                <h1 className="text-4xl sm:text-5xl font-extrabold text-white leading-tight">
                    O Fim do "Copia e Cola".<br/> <span className="text-[var(--color-accent)]">Unifique suas Ferramentas e Automatize seu Crescimento.</span>
                </h1>
                <p className="mt-4 text-xl text-gray-400 max-w-3xl mx-auto">
                    Nós construímos um Hub de Inteligência que conecta as ferramentas que você já usa, criando uma visão 360º do seu cliente e automatizando seus processos de ponta a ponta.
                </p>
            </header>
            <main>
                <section id="contact" className="mt-16 text-center">
                    <h3 className="text-3xl font-bold text-white">Pronto para ser o dono da sua tecnologia?</h3>
                     <button onClick={() => setActiveView('chat')} className="mt-6 inline-block bg-[var(--color-accent)] text-white font-bold py-4 px-10 rounded-lg hover:bg-[var(--color-accent-hover)] transition-colors text-xl shadow-[0_4px_14px_0_rgb(0,118,255,39%)] hover:shadow-[0_6px_20px_rgb(0,118,255,23%)]">
                        Sim, Quero Meu Diagnóstico!
                    </button>
                    <p className="text-gray-500 mt-2 text-sm">Vagas limitadas para garantir a qualidade da consultoria.</p>
                </section>
            </main>
        </>
    );

    const LandingPageView: React.FC<{ version: 'A' | 'B'; setVersion: (v: 'A' | 'B') => void; }> = ({ version, setVersion }) => {
         const handleResetTest = () => {
            localStorage.removeItem('marketeriaLPVersion');
            window.location.reload();
        };

        return (
            <div className="max-w-4xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
                <div className="fixed top-4 right-4 bg-[var(--color-secondary)] p-3 rounded-lg shadow-lg z-10 text-sm w-48">
                    <p className="font-bold text-white border-b border-gray-600 pb-2 mb-2">A/B Test Control</p>
                    <p className="text-gray-400 mb-2">
                        Viewing: <span className="font-bold text-[var(--color-accent)]">Version {version}</span>
                    </p>
                    <div className="flex space-x-2 mb-2">
                         <button 
                            onClick={() => setVersion('A')} 
                            className={`flex-1 text-xs py-1 rounded transition-colors ${version === 'A' ? 'bg-[var(--color-accent)] text-white' : 'bg-gray-600 hover:bg-gray-500'}`}>
                            View A
                        </button>
                        <button 
                            onClick={() => setVersion('B')} 
                            className={`flex-1 text-xs py-1 rounded transition-colors ${version === 'B' ? 'bg-[var(--color-accent)] text-white' : 'bg-gray-600 hover:bg-gray-500'}`}>
                            View B
                        </button>
                    </div>
                    <button onClick={handleResetTest} className="w-full text-center text-xs text-blue-400 hover:underline mt-1">
                        Reset for new visit
                    </button>
                </div>
                {version === 'A' ? <LandingPageViewA /> : <LandingPageViewB />}
            </div>
        )
    };
    
    const ConsultingServicesView: React.FC = () => {
        const CTAButton: React.FC<{ children: React.ReactNode }> = ({ children }) => (
            <button onClick={() => setActiveView('chat')} className="mt-6 inline-block bg-[var(--color-accent)] text-white font-bold py-4 px-10 rounded-lg hover:bg-[var(--color-accent-hover)] transition-colors text-lg shadow-[0_4px_14px_0_rgb(37,99,235,39%)] hover:shadow-[0_6px_20px_rgb(37,99,235,23%)]">
                {children} &rarr;
            </button>
        );

        return (
            <div className="max-w-5xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
                {/* Hero Section */}
                <header className="text-center mb-20">
                    <h1 className="text-4xl sm:text-6xl font-extrabold text-white leading-tight">
                        Transforme seu Marketing em uma <span className="text-[var(--color-accent)]">Máquina de Receita Previsível</span>.
                    </h1>
                    <p className="mt-6 text-xl text-gray-400 max-w-3xl mx-auto">
                        Nós implementamos sistemas de marketing e vendas que geram leads qualificados e clientes todos os dias, de forma automatizada e com base em inovação.
                    </p>
                    <CTAButton>Quero um Diagnóstico Estratégico</CTAButton>
                </header>

                {/* Problem Section */}
                <section className="mb-20">
                    <h2 className="text-3xl font-bold text-center text-white mb-10">Seu negócio sofre com...</h2>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                        <div className="bg-[var(--color-secondary)] p-6 rounded-lg">
                            <h3 className="text-xl font-bold text-[var(--color-accent)] mb-2">Geração de Leads Imprevisível</h3>
                            <p className="text-gray-400">Um mês você tem muitos leads, no outro, quase nenhum. A falta de previsibilidade impede o crescimento.</p>
                        </div>
                        <div className="bg-[var(--color-secondary)] p-6 rounded-lg">
                            <h3 className="text-xl font-bold text-[var(--color-accent)] mb-2">Equipe Sobrecarregada</h3>
                            <p className="text-gray-400">Sua equipe gasta mais tempo em tarefas repetitivas do que em estratégia e vendas, gerando gargalos e desmotivação.</p>
                        </div>
                        <div className="bg-[var(--color-secondary)] p-6 rounded-lg">
                            <h3 className="text-xl font-bold text-[var(--color-accent)] mb-2">Ferramentas Desconectadas</h3>
                            <p className="text-gray-400">Você usa múltiplas plataformas que não se comunicam, criando silos de dados e uma visão fragmentada do seu cliente.</p>
                        </div>
                    </div>
                </section>

                {/* Solution Section */}
                <section className="mb-20 text-center">
                    <h2 className="text-3xl font-bold text-white">A Solução: Consultoria & Assessoria Estratégica</h2>
                    <p className="mt-4 text-lg text-gray-400 max-w-3xl mx-auto">Nós não apenas entregamos um plano. Nós construímos e implementamos o sistema de crescimento junto com você.</p>
                    <div className="mt-8 flex flex-col md:flex-row gap-8 max-w-4xl mx-auto">
                        <div className="flex-1 bg-[var(--color-secondary)] p-8 rounded-lg border-l-4 border-[var(--color-accent)]">
                            <h3 className="text-2xl font-bold">Consultoria (O Plano)</h3>
                            <p className="mt-2 text-gray-400">Analisamos seu negócio, mercado e metas para desenhar um plano de ação detalhado, focado em resultados rápidos e sustentáveis.</p>
                        </div>
                        <div className="flex-1 bg-[var(--color-secondary)] p-8 rounded-lg border-l-4 border-cyan-500">
                            <h3 className="text-2xl font-bold">Assessoria (A Execução)</h3>
                            <p className="mt-2 text-gray-400">Colocamos a mão na massa para implementar as automações, campanhas e processos definidos na estratégia, garantindo que tudo funcione perfeitamente.</p>
                        </div>
                    </div>
                </section>
                
                 {/* How it works Section */}
                <section className="mb-20">
                     <h2 className="text-3xl font-bold text-center text-white mb-12">Nosso Processo de Crescimento Acelerado</h2>
                     <div className="relative">
                        <div className="absolute left-1/2 top-0 bottom-0 w-px bg-gray-700 hidden md:block" aria-hidden="true"></div>
                        <div className="space-y-12">
                            <div className="md:flex items-center">
                                <div className="md:w-1/2 md:pr-8 text-center md:text-right">
                                    <div className="inline-block bg-[var(--color-accent)] text-white rounded-full w-12 h-12 flex items-center justify-center font-bold text-xl mb-2">1</div>
                                    <h3 className="text-2xl font-bold text-white">Diagnóstico e Imersão</h3>
                                    <p className="text-gray-400">Mapeamos 100% dos seus processos atuais para encontrar os pontos de maior alavancagem.</p>
                                </div>
                                <div className="md:w-1/2 md:pl-8"></div>
                            </div>
                             <div className="md:flex items-center">
                                <div className="md:w-1/2 md:pr-8"></div>
                                <div className="md:w-1/2 md:pl-8 text-center md:text-left">
                                     <div className="inline-block bg-[var(--color-accent)] text-white rounded-full w-12 h-12 flex items-center justify-center font-bold text-xl mb-2">2</div>
                                    <h3 className="text-2xl font-bold text-white">Plano Estratégico</h3>
                                    <p className="text-gray-400">Entregamos um plano de automação e marketing com ações claras, KPIs e cronograma.</p>
                                </div>
                            </div>
                            <div className="md:flex items-center">
                                <div className="md:w-1/2 md:pr-8 text-center md:text-right">
                                     <div className="inline-block bg-[var(--color-accent)] text-white rounded-full w-12 h-12 flex items-center justify-center font-bold text-xl mb-2">3</div>
                                    <h3 className="text-2xl font-bold text-white">Implementação e Inovação</h3>
                                    <p className="text-gray-400">Construímos os fluxos, ativamos as campanhas e integramos suas ferramentas com IA.</p>
                                </div>
                                <div className="md:w-1/2 md:pl-8"></div>
                            </div>
                             <div className="md:flex items-center">
                                <div className="md:w-1/2 md:pr-8"></div>
                                <div className="md:w-1/2 md:pl-8 text-center md:text-left">
                                     <div className="inline-block bg-[var(--color-accent)] text-white rounded-full w-12 h-12 flex items-center justify-center font-bold text-xl mb-2">4</div>
                                    <h3 className="text-2xl font-bold text-white">Crescimento Diário</h3>
                                    <p className="text-gray-400">Monitoramos e otimizamos o sistema para garantir a geração diária de leads e vendas.</p>
                                </div>
                            </div>
                        </div>
                     </div>
                </section>
                
                {/* Social Proof */}
                <section className="mb-20">
                    <h2 className="text-3xl font-bold text-center text-white mb-10">O que nossos clientes dizem</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
                        <div className="bg-[var(--color-secondary)] p-6 rounded-lg">
                            <blockquote className="text-gray-300 italic">"A Marketeria mudou o jogo para nós. Saímos de um processo de vendas manual e imprevisível para um sistema que nos traz oportunidades qualificadas todos os dias. O investimento se pagou em menos de 2 meses."</blockquote>
                            <p className="mt-4 font-bold text-white">- João Silva, CEO da Tech Solutions</p>
                        </div>
                        <div className="bg-[var(--color-secondary)] p-6 rounded-lg">
                            <blockquote className="text-gray-300 italic">"Finalmente temos uma visão clara do nosso funil de marketing. As automações liberaram nossa equipe para focar no que realmente importa: o relacionamento com o cliente. Recomendo fortemente."</blockquote>
                            <p className="mt-4 font-bold text-white">- Maria Oliveira, Diretora de Marketing da Inova Corp</p>
                        </div>
                    </div>
                </section>

                {/* Final CTA */}
                <section className="text-center bg-[var(--color-secondary)] p-12 rounded-lg">
                    <h2 className="text-3xl sm:text-4xl font-extrabold text-white">Pronto para construir seu futuro?</h2>
                    <p className="mt-4 text-lg text-gray-400 max-w-2xl mx-auto">Agende uma conversa sem compromisso e receba um diagnóstico gratuito de como a automação e a inovação podem dobrar seus resultados em 90 dias.</p>
                    <CTAButton>Agendar meu Diagnóstico</CTAButton>
                </section>
            </div>
        );
    };

    const MetricsDashboardView: React.FC = () => {
        const totalLeads = leads.length;
        const totalWins = leads.filter(l => l.stage === 'Cliente (Ganho)').length;
        const overallConversionRate = totalLeads > 0 ? (totalWins / totalLeads * 100).toFixed(1) : 0;
        const avgScore = totalLeads > 0 ? (leads.reduce((sum, l) => sum + (l.score || 0), 0) / totalLeads).toFixed(0) : 0;

        // A/B Test calculations
        const leadsA = leads.filter(l => l.landingPageVersion === 'A');
        const leadsB = leads.filter(l => l.landingPageVersion === 'B');
        const winsA = leadsA.filter(l => l.stage === 'Cliente (Ganho)').length;
        const winsB = leadsB.filter(l => l.stage === 'Cliente (Ganho)').length;
        const conversionRateA = leadsA.length > 0 ? (winsA / leadsA.length) * 100 : 0;
        const conversionRateB = leadsB.length > 0 ? (winsB / leadsB.length) * 100 : 0;

        const winner = conversionRateA > conversionRateB ? 'A' : conversionRateB > conversionRateA ? 'B' : 'None';


        return (
            <div>
                <h2 className="text-3xl font-bold mb-6">Painel de Métricas</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <div className="bg-[var(--color-secondary)] p-6 rounded-lg">
                        <h3 className="text-lg font-semibold text-gray-400">Total de Leads</h3>
                        <p className="text-4xl font-bold text-white mt-2">{totalLeads}</p>
                    </div>
                    <div className="bg-[var(--color-secondary)] p-6 rounded-lg">
                        <h3 className="text-lg font-semibold text-gray-400">Total de Clientes</h3>
                        <p className="text-4xl font-bold text-white mt-2">{totalWins}</p>
                    </div>
                    <div className="bg-[var(--color-secondary)] p-6 rounded-lg">
                        <h3 className="text-lg font-semibold text-gray-400">Taxa de Conversão</h3>
                        <p className="text-4xl font-bold text-white mt-2">{overallConversionRate}%</p>
                    </div>
                     <div className="bg-[var(--color-secondary)] p-6 rounded-lg">
                        <h3 className="text-lg font-semibold text-gray-400">Lead Score Médio</h3>
                        <p className="text-4xl font-bold text-white mt-2">{avgScore}</p>
                    </div>
                </div>
                <div className="mt-8 bg-[var(--color-secondary)] p-6 rounded-lg">
                    <h3 className="text-xl font-bold mb-4 text-center">Desempenho do Teste A/B</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                        {/* Version A Card */}
                        <div className={`p-4 rounded-lg border-2 ${winner === 'A' ? 'border-[var(--color-accent)]' : 'border-transparent'}`}>
                            <div className="flex justify-between items-center">
                                <h4 className="font-bold text-lg text-white">Versão A (Scale)</h4>
                                {winner === 'A' && <span className="text-yellow-400 text-2xl" title="Winning Version">👑</span>}
                            </div>
                            <div className="mt-4 space-y-2">
                                <div className="flex justify-between"><span>Total de Leads:</span> <span className="font-bold">{leadsA.length}</span></div>
                                <div className="flex justify-between"><span>Clientes Gerados:</span> <span className="font-bold">{winsA}</span></div>
                                <div className="flex justify-between text-lg text-[var(--color-accent)]"><span>Taxa de Conversão:</span> <span className="font-bold">{conversionRateA.toFixed(1)}%</span></div>
                            </div>
                        </div>

                        {/* Version B Card */}
                        <div className={`p-4 rounded-lg border-2 ${winner === 'B' ? 'border-[var(--color-accent)]' : 'border-transparent'}`}>
                             <div className="flex justify-between items-center">
                                <h4 className="font-bold text-lg text-white">Versão B (Selective)</h4>
                                {winner === 'B' && <span className="text-yellow-400 text-2xl" title="Winning Version">👑</span>}
                            </div>
                             <div className="mt-4 space-y-2">
                                <div className="flex justify-between"><span>Total de Leads:</span> <span className="font-bold">{leadsB.length}</span></div>
                                <div className="flex justify-between"><span>Clientes Gerados:</span> <span className="font-bold">{winsB}</span></div>
                                <div className="flex justify-between text-lg text-[var(--color-accent)]"><span>Taxa de Conversão:</span> <span className="font-bold">{conversionRateB.toFixed(1)}%</span></div>
                            </div>
                        </div>
                    </div>
                     <p className="text-center text-gray-400 mt-6 text-sm">A análise é baseada na conversão de 'Lead' para 'Cliente (Ganho)'.</p>
                </div>
            </div>
        );
    };

    // Fix: Implement ChatView component.
    const ChatView: React.FC<{ addLead: (lead: Omit<Lead, 'id' | 'capturedAt' | 'stage' | 'landingPageVersion' | 'score' | 'scoreReason' | 'isScoring'>) => void }> = ({ addLead }) => {
        const [messages, setMessages] = useState<ChatMessage[]>([
            { text: "Olá! Sou o assistente da Marketeria. Para começar, qual é o seu nome?", isUser: false }
        ]);
        const [input, setInput] = useState('');
        const [chatState, setChatState] = useState<'collecting_name' | 'collecting_email' | 'collecting_company' | 'collecting_term' | 'done'>('collecting_name');
        const [leadData, setLeadData] = useState({ name: '', email: '', company: '', searchTerm: 'Direct Traffic / Unknown', chatHistory: messages });

        const handleSend = () => {
            if (!input.trim()) return;

            const userMessage: ChatMessage = { text: input, isUser: true };
            const newMessages = [...messages, userMessage];
            let nextBotMessage: ChatMessage | null = null;
            let nextState = chatState;
            
            const updatedLeadData = { ...leadData };

            switch (chatState) {
                case 'collecting_name':
                    updatedLeadData.name = input;
                    nextBotMessage = { text: `Prazer, ${input}! E qual o seu melhor e-mail?`, isUser: false };
                    nextState = 'collecting_email';
                    break;
                case 'collecting_email':
                    updatedLeadData.email = input;
                    nextBotMessage = { text: "Ótimo. E o nome da sua empresa?", isUser: false };
                    nextState = 'collecting_company';
                    break;
                case 'collecting_company':
                    updatedLeadData.company = input;
                    nextBotMessage = { text: "Perfeito! Para finalizar, como você nos encontrou?", isUser: false };
                    nextState = 'collecting_term';
                    break;
                case 'collecting_term':
                    updatedLeadData.searchTerm = input;
                    nextBotMessage = { text: "Obrigado! Um de nossos especialistas entrará em contato em breve. Enquanto isso, você será redirecionado para o nosso painel.", isUser: false };
                    nextState = 'done';
                    break;
            }

            if (nextBotMessage) {
                newMessages.push(nextBotMessage);
            }
            
            updatedLeadData.chatHistory = newMessages;
            setMessages(newMessages);
            setLeadData(updatedLeadData);
            setChatState(nextState);
            setInput('');

            if (nextState === 'done') {
                addLead(updatedLeadData);
                setTimeout(() => setActiveView('dashboard'), 3000);
            }
        };
        
        return (
            <div className="max-w-2xl mx-auto flex flex-col h-[70vh] bg-[var(--color-secondary)] rounded-lg shadow-xl">
                <div className="p-4 border-b border-gray-700">
                    <h2 className="text-xl font-bold text-white text-center">Diagnóstico Gratuito</h2>
                </div>
                <div className="flex-1 p-4 overflow-y-auto space-y-4">
                    {messages.map((msg, index) => (
                        <div key={index} className={`flex ${msg.isUser ? 'justify-end' : 'justify-start'}`}>
                            <div className={`px-4 py-2 rounded-lg max-w-xs lg:max-w-md ${msg.isUser ? 'bg-[var(--color-accent)] text-white' : 'bg-gray-700 text-gray-200'}`}>
                                {msg.text}
                            </div>
                        </div>
                    ))}
                </div>
                <div className="p-4 border-t border-gray-700">
                    <div className="flex">
                        <input
                            type="text"
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                            className="flex-1 bg-[var(--color-dark)] border border-gray-600 rounded-l-md p-2 focus:ring-2 focus:ring-[var(--color-accent)] focus:border-[var(--color-accent)]"
                            placeholder="Digite sua mensagem..."
                            disabled={chatState === 'done'}
                        />
                        <button onClick={handleSend} disabled={chatState === 'done'} className="bg-[var(--color-accent)] text-white font-bold py-2 px-4 rounded-r-lg hover:bg-[var(--color-accent-hover)] transition-colors disabled:opacity-50">
                            Enviar
                        </button>
                    </div>
                </div>
            </div>
        );
    };

    // Fix: Implement FunnelDashboardView component.
    const FunnelDashboardView: React.FC<{ leads: Lead[] }> = ({ leads }) => {
        const stages: LeadStage[] = ['Caixa de Entrada', 'Qualificação', 'Oportunidade', 'Cliente (Ganho)', 'Perdido'];

        const getLeadsByStage = (stage: LeadStage) => leads.filter(lead => lead.stage === stage);

        const stageColors: Record<LeadStage, string> = {
            'Caixa de Entrada': 'border-t-blue-500',
            'Qualificação': 'border-t-purple-500',
            'Oportunidade': 'border-t-yellow-500',
            'Cliente (Ganho)': 'border-t-green-500',
            'Perdido': 'border-t-red-500',
        };
        
        return (
            <div>
                <h2 className="text-3xl font-bold mb-6">Funil de Vendas</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                    {stages.map(stage => (
                        <div key={stage} className="bg-[var(--color-secondary)] rounded-lg p-4">
                            <h3 className={`font-bold text-lg mb-4 pb-2 border-b-2 ${stageColors[stage].replace('border-t-', 'border-b-')}`}>{stage} ({getLeadsByStage(stage).length})</h3>
                            <div className="space-y-3">
                                {getLeadsByStage(stage).map(lead => (
                                    <div key={lead.id} className={`p-3 bg-[var(--color-dark)] rounded-md shadow-lg border-l-4 ${stageColors[stage].replace('border-t-', 'border-l-')}`}>
                                        <p className="font-bold text-white">{lead.name}</p>
                                        <p className="text-sm text-gray-400">{lead.company}</p>
                                    </div>
                                ))}
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        );
    };

    // Fix: Implement PromptLibraryView component.
    const PromptLibraryView: React.FC = () => {
        const [assistantType, setAssistantType] = useState('crm-strategist');
        const [userPrompt, setUserPrompt] = useState('');
        const [dataContext, setDataContext] = useState('');
        const [response, setResponse] = useState('');
        const [isLoading, setIsLoading] = useState(false);
        const [error, setError] = useState('');
        
        const assistants = [
            { id: 'crm-strategist', name: 'CRM & Automation Strategist' },
            { id: 'sales-copywriter', name: 'Sales Copywriter' },
            { id: 'content-strategist', name: 'B2B Content Strategist' },
            { id: 'business-consultant', name: 'Business Consultant' },
            { id: 'general-assistant', name: 'General Assistant' },
        ];

        const handleGenerate = async () => {
            setIsLoading(true);
            setError('');
            setResponse('');
            try {
                const result = await generateAssistantResponse(userPrompt, assistantType, dataContext);
                setResponse(result);
            } catch (e) {
                setError('Failed to get a response from the AI assistant.');
                console.error(e);
            } finally {
                setIsLoading(false);
            }
        };
        
        return (
            <div>
                <h2 className="text-3xl font-bold mb-6">Biblioteca de IA</h2>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-1">
                        <div className="bg-[var(--color-secondary)] p-6 rounded-lg">
                            <label htmlFor="assistantType" className="block text-sm font-medium text-gray-300 mb-2">Select Assistant Persona</label>
                            <select
                                id="assistantType"
                                value={assistantType}
                                onChange={e => setAssistantType(e.target.value)}
                                className="w-full bg-[var(--color-dark)] border border-gray-600 rounded-md p-2 focus:ring-2 focus:ring-[var(--color-accent)] focus:border-[var(--color-accent)]"
                            >
                                {assistants.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                            </select>
                            
                            <label htmlFor="userPrompt" className="block text-sm font-medium text-gray-300 mb-2 mt-4">Your Request</label>
                            <textarea
                                id="userPrompt"
                                value={userPrompt}
                                onChange={e => setUserPrompt(e.target.value)}
                                rows={5}
                                className="w-full bg-[var(--color-dark)] border border-gray-600 rounded-md p-2 focus:ring-2 focus:ring-[var(--color-accent)] focus:border-[var(--color-accent)]"
                                placeholder="e.g., Write a LinkedIn post about the problem with traditional CRMs."
                            />

                            <label htmlFor="dataContext" className="block text-sm font-medium text-gray-300 mb-2 mt-4">Additional Context (Optional)</label>
                            <textarea
                                id="dataContext"
                                value={dataContext}
                                onChange={e => setDataContext(e.target.value)}
                                rows={3}
                                className="w-full bg-[var(--color-dark)] border border-gray-600 rounded-md p-2 focus:ring-2 focus:ring-[var(--color-accent)] focus:border-[var(--color-accent)]"
                                placeholder="e.g., Paste client data, an article, or other relevant text here."
                            />

                            <button
                                onClick={handleGenerate}
                                disabled={isLoading || !userPrompt}
                                className="mt-4 w-full flex justify-center items-center gap-2 bg-[var(--color-accent)] text-white font-bold py-2 px-4 rounded-lg hover:bg-[var(--color-accent-hover)] transition-colors disabled:opacity-50"
                            >
                                {isLoading ? 'Generating...' : <><SparklesIcon className="w-5 h-5" /> Generate Response</>}
                            </button>
                        </div>
                    </div>
                    <div className="lg:col-span-2">
                        <div className="bg-[var(--color-secondary)] p-6 rounded-lg min-h-[400px]">
                             <h3 className="text-xl font-bold text-white mb-4">AI Assistant Response</h3>
                             {isLoading && <Spinner />}
                             {error && <p className="text-red-400">{error}</p>}
                             {response ? (
                                <div className="prose prose-invert max-w-none text-gray-300 whitespace-pre-wrap">{response}</div>
                             ) : (
                                !isLoading && <p className="text-gray-400">The assistant's response will appear here.</p>
                             )}
                        </div>
                    </div>
                </div>
            </div>
        );
    };

    const BrandKitView: React.FC<{ brandColors: Record<string, string> }> = ({ brandColors }) => {
        const handlePrint = () => {
            window.print();
        };

        return (
            <div>
                 <div className="flex justify-between items-center mb-6">
                    <h2 className="text-3xl font-bold">Manual de Identidade Visual</h2>
                    <button
                        onClick={handlePrint}
                        className="inline-flex items-center gap-2 bg-[var(--color-accent)] text-white font-bold py-2 px-4 rounded-lg hover:bg-[var(--color-accent-hover)] transition-colors"
                    >
                        <DownloadIcon /> Gerar PDF
                    </button>
                </div>
                <div className="printable-area bg-[var(--color-dark)] p-8 rounded-lg">
                    <h1 className="text-4xl font-bold text-white mb-8 border-b border-gray-700 pb-4">Manual da Marca: Marketeria</h1>
                    
                    <section>
                        <h2 className="text-2xl font-bold text-[var(--color-accent)] mb-4">Paleta de Cores Primária</h2>
                        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                            {Object.entries(brandColors).map(([name, color]) => (
                                <div key={name}>
                                    <div className={`w-full h-24 rounded-lg shadow-lg`} style={{ backgroundColor: color, border: name === 'light' ? '1px solid #374151' : 'none' }}></div>
                                    <p className="mt-2 text-white font-semibold capitalize">{name}</p>
                                    <p className="text-gray-400 text-sm">{color}</p>
                                </div>
                            ))}
                        </div>
                    </section>
                     <section className="mt-12">
                        <h2 className="text-2xl font-bold text-[var(--color-accent)] mb-4">Paleta de Cores Semântica</h2>
                        <p className="text-gray-400 mb-4 max-w-2xl">Cores usadas para comunicar status e ações ao usuário de forma rápida e intuitiva, melhorando a usabilidade.</p>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            <div><div className="w-full h-24 rounded-lg shadow-lg bg-green-500"></div><p className="mt-2 text-white font-semibold">Success</p><p className="text-gray-400 text-sm">#22C55E</p></div>
                            <div><div className="w-full h-24 rounded-lg shadow-lg bg-red-500"></div><p className="mt-2 text-white font-semibold">Error / Danger</p><p className="text-gray-400 text-sm">#EF4444</p></div>
                            <div><div className="w-full h-24 rounded-lg shadow-lg bg-yellow-500"></div><p className="mt-2 text-white font-semibold">Warning</p><p className="text-gray-400 text-sm">#EAB308</p></div>
                            <div><div className="w-full h-24 rounded-lg shadow-lg bg-sky-500"></div><p className="mt-2 text-white font-semibold">Information</p><p className="text-gray-400 text-sm">#0EA5E9</p></div>
                        </div>
                    </section>
                    
                    <section className="mt-12">
                         <h2 className="text-2xl font-bold text-[var(--color-accent)] mb-4">Tipografia</h2>
                         <div className="bg-secondary-for-print bg-[var(--color-secondary)] p-6 rounded-lg">
                            <div>
                                <p className="text-sm text-gray-400">Títulos (H1, H2, H3)</p>
                                <p className="text-4xl font-extrabold text-white">Aa - System UI (Extrabold)</p>
                            </div>
                            <div className="mt-6">
                                <p className="text-sm text-gray-400">Corpo do Texto & Labels</p>
                                <p className="text-lg text-gray-300">Aa - System UI (Regular)</p>
                            </div>
                         </div>
                    </section>

                    <section className="mt-12">
                         <h2 className="text-2xl font-bold text-[var(--color-accent)] mb-4">Estados de Componentes</h2>
                         <p className="text-gray-400 mb-4 max-w-2xl">Essencial para UX, os estados fornecem feedback visual para as interações do usuário, tornando a interface responsiva e intuitiva.</p>
                         <div className="bg-secondary-for-print bg-[var(--color-secondary)] p-6 rounded-lg space-y-8">
                            {/* Buttons */}
                            <div>
                                <h3 className="text-xl font-bold text-white mb-4">Botões</h3>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                                    <div>
                                        <p className="text-gray-400 mb-2">Padrão</p>
                                        <button className="bg-[var(--color-accent)] text-white font-bold py-2 px-4 rounded-lg">Action</button>
                                    </div>
                                    <div>
                                        <p className="text-gray-400 mb-2">Hover</p>
                                        <button className="bg-[var(--color-accent-hover)] text-white font-bold py-2 px-4 rounded-lg">Action</button>
                                    </div>
                                    <div>
                                        <p className="text-gray-400 mb-2">Disabled</p>
                                        <button className="bg-[var(--color-accent)] text-white font-bold py-2 px-4 rounded-lg opacity-50 cursor-not-allowed">Action</button>
                                    </div>
                                </div>
                            </div>
                             {/* Inputs */}
                            <div>
                                <h3 className="text-xl font-bold text-white mb-4">Inputs</h3>
                                 <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <div>
                                         <p className="text-gray-400 mb-2">Padrão</p>
                                         <input type="text" placeholder="Seu nome..." className="w-full bg-[var(--color-dark)] border border-gray-600 rounded-md p-2 focus:ring-2 focus:ring-[var(--color-accent)] focus:border-[var(--color-accent)]" />
                                    </div>
                                     <div>
                                         <p className="text-gray-400 mb-2">Erro</p>
                                         <input type="text" placeholder="email@invalido" defaultValue="email@invalido" className="w-full bg-[var(--color-dark)] border border-red-500 rounded-md p-2 ring-2 ring-red-500/50" />
                                    </div>
                                    <div>
                                        <p className="text-gray-400 mb-2">Disabled</p>
                                        <input type="text" placeholder="Não editável" className="w-full bg-gray-800 border border-gray-700 rounded-md p-2 cursor-not-allowed opacity-60" disabled />
                                    </div>
                                 </div>
                            </div>
                         </div>
                    </section>
                    
                     <section className="mt-12">
                        <h2 className="text-2xl font-bold text-[var(--color-accent)] mb-4">Tom de Voz</h2>
                        <div className="bg-secondary-for-print bg-[var(--color-secondary)] p-6 rounded-lg">
                             <blockquote className="border-l-4 border-[var(--color-accent)] pl-4 italic my-2 text-gray-300 text-lg">
                               "Estratégico, Direto e Didático."
                            </blockquote>
                            <p className="text-gray-400 mt-4 pl-5">Nossa comunicação é focada em clareza e valor. Explicamos o "porquê" por trás das automações, evitamos jargões desnecessários e nos posicionamos como um parceiro que educa e capacita o cliente.</p>
                        </div>
                    </section>
                </div>
            </div>
        );
    };

    const AnalyticsDashboardView: React.FC<{ leads: Lead[] }> = ({ leads }) => {
        const [dateRange, setDateRange] = useState(30); // in days, 0 for all time

        const filteredData = useMemo(() => {
            const now = new Date();
            const cutoffDate = new Date();
            if (dateRange > 0) {
                cutoffDate.setDate(now.getDate() - dateRange);
            }

            const relevantLeads = dateRange === 0 
                ? leads 
                : leads.filter(l => new Date(l.capturedAt) >= cutoffDate);
            
            const wonLeads = relevantLeads.filter(l => l.stage === 'Cliente (Ganho)' && l.closedAt && (dateRange === 0 || new Date(l.closedAt) >= cutoffDate));

            return {
                leads: relevantLeads,
                wonLeads,
            };
        }, [leads, dateRange]);

        const totalRevenue = filteredData.wonLeads.reduce((sum, l) => sum + (l.value || 0), 0);
        const totalLeads = filteredData.leads.length;
        const conversionRate = totalLeads > 0 ? (filteredData.wonLeads.length / totalLeads) * 100 : 0;

        const funnelData = useMemo(() => {
            const stages: LeadStage[] = ['Caixa de Entrada', 'Qualificação', 'Oportunidade', 'Cliente (Ganho)'];
            let leadsInFunnel = [...filteredData.leads];
            
            const stageCounts = stages.map(stage => {
                const count = leads.filter(l => {
                     const stageIndex = stages.indexOf(l.stage);
                     const currentStageIndex = stages.indexOf(stage);
                     return stageIndex >= currentStageIndex;
                }).length;
                return { stage, count };
            });

             // We must ensure the funnel is always decreasing
            for (let i = 1; i < stageCounts.length; i++) {
                if (stageCounts[i].count > stageCounts[i-1].count) {
                    stageCounts[i].count = stageCounts[i-1].count;
                }
            }

            return stageCounts;

        }, [filteredData.leads, leads]);

        const RevenueChart: React.FC = () => {
             const dataPoints = useMemo(() => {
                const points: { [key: string]: number } = {};
                filteredData.wonLeads.forEach(lead => {
                    if (lead.closedAt) {
                        const date = new Date(lead.closedAt).toLocaleDateString();
                        points[date] = (points[date] || 0) + (lead.value || 0);
                    }
                });
                return Object.entries(points).map(([date, revenue]) => ({ date: new Date(date), revenue })).sort((a, b) => a.date.getTime() - b.date.getTime());
            }, [filteredData.wonLeads]);

            if (dataPoints.length < 2) {
                return <div className="flex items-center justify-center h-full text-gray-500">Not enough data to display chart.</div>
            }

            const maxRevenue = Math.max(...dataPoints.map(p => p.revenue));
            const chartHeight = 200;
            const chartWidth = 500;

            const path = dataPoints.map((point, i) => {
                const x = (i / (dataPoints.length - 1)) * chartWidth;
                const y = chartHeight - (point.revenue / maxRevenue) * chartHeight;
                return `${i === 0 ? 'M' : 'L'} ${x},${y}`;
            }).join(' ');

            return (
                <div className="w-full">
                    <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="w-full h-auto">
                        <path d={path} stroke="var(--color-accent)" fill="none" strokeWidth="2" />
                    </svg>
                </div>
            );
        };
        
        return (
            <div>
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-3xl font-bold">Analytics Dashboard</h2>
                    <div className="flex items-center gap-2 p-1 bg-[var(--color-secondary)] rounded-lg">
                        {[
                            { label: '7D', days: 7 },
                            { label: '30D', days: 30 },
                            { label: '90D', days: 90 },
                            { label: 'All', days: 0 }
                        ].map(({ label, days }) => (
                            <button
                                key={days}
                                onClick={() => setDateRange(days)}
                                className={`px-3 py-1 rounded-md text-sm font-semibold transition-colors ${dateRange === days ? 'bg-[var(--color-accent)] text-white' : 'text-gray-400 hover:bg-gray-700'}`}
                            >
                                {label}
                            </button>
                        ))}
                    </div>
                </div>

                {/* KPI Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="bg-[var(--color-secondary)] p-6 rounded-lg">
                        <h3 className="text-lg font-semibold text-gray-400">Total Revenue</h3>
                        <p className="text-4xl font-bold text-white mt-2">
                            ${totalRevenue.toLocaleString('en-US', { maximumFractionDigits: 0 })}
                        </p>
                    </div>
                     <div className="bg-[var(--color-secondary)] p-6 rounded-lg">
                        <h3 className="text-lg font-semibold text-gray-400">New Leads</h3>
                        <p className="text-4xl font-bold text-white mt-2">{totalLeads}</p>
                    </div>
                    <div className="bg-[var(--color-secondary)] p-6 rounded-lg">
                        <h3 className="text-lg font-semibold text-gray-400">Conversion Rate</h3>
                        <p className="text-4xl font-bold text-white mt-2">{conversionRate.toFixed(1)}%</p>
                    </div>
                </div>

                {/* Charts */}
                <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 mt-8">
                    <div className="lg:col-span-3 bg-[var(--color-secondary)] p-6 rounded-lg">
                        <h3 className="text-xl font-bold mb-4">Revenue Over Time</h3>
                        <RevenueChart />
                    </div>
                     <div className="lg:col-span-2 bg-[var(--color-secondary)] p-6 rounded-lg">
                        <h3 className="text-xl font-bold mb-4">Lead Conversion Funnel</h3>
                        <div className="space-y-2 mt-4">
                            {funnelData.map((item, index) => {
                                const prevCount = index > 0 ? funnelData[index - 1].count : item.count;
                                const conversion = prevCount > 0 ? (item.count / prevCount * 100).toFixed(1) : '100.0';
                                const widthPercentage = funnelData[0].count > 0 ? (item.count / funnelData[0].count) * 100 : 0;
                                return (
                                    <div key={item.stage} className="text-center">
                                        <div className="flex justify-between items-center text-sm mb-1 px-2">
                                            <span className="font-semibold text-gray-300">{item.stage}</span>
                                            {index > 0 && <span className="text-xs text-cyan-400">{conversion}% &rarr;</span>}
                                        </div>
                                        <div className="bg-gray-700 rounded-sm mx-auto" style={{ width: `${100 - index * 5}%` }}>
                                             <div className="bg-[var(--color-accent)] h-8 rounded-sm flex items-center justify-center" style={{ width: `${widthPercentage}%` }}>
                                                <span className="font-bold text-white">{item.count}</span>
                                            </div>
                                        </div>
                                    </div>
                                )
                            })}
                        </div>
                    </div>
                </div>
                 <div className="mt-8 bg-[var(--color-secondary)] p-6 rounded-lg">
                    <h3 className="text-xl font-bold mb-2">Workflow Usage</h3>
                    <p className="text-gray-500 text-center py-8">Workflow usage tracking and analytics coming soon.</p>
                </div>
            </div>
        );
    };

    const LeadsView: React.FC<{ leads: Lead[]; onUpdateLeadStage: (leadId: string, newStage: LeadStage) => void }> = ({ leads, onUpdateLeadStage }) => {
        const [viewMode, setViewMode] = useState<'kanban' | 'list'>('kanban');
        const [viewingLead, setViewingLead] = useState<Lead | null>(null);
        const [processingAI, setProcessingAI] = useState<string | null>(null);

        const handleAIDrag = async (lead: Lead) => {
            if (processingAI) return;
            setProcessingAI(lead.id);
            try {
                const nextStage = await suggestNextLeadStage(lead);
                onUpdateLeadStage(lead.id, nextStage);
            } catch (error) {
                console.error("AI stage suggestion failed", error);
            } finally {
                setProcessingAI(null);
            }
        };

        const LeadScore: React.FC<{ score?: number; reason?: string }> = ({ score, reason }) => {
            if (typeof score === 'undefined') return null;
            const getColor = () => score > 75 ? 'bg-green-600 text-green-100' : score > 40 ? 'bg-yellow-600 text-yellow-100' : 'bg-red-600 text-red-100';
            const getFlame = () => score > 75 ? '🔥🔥🔥' : score > 40 ? '🔥' : '❄️';
            return (
                <div className="group relative">
                    <span className={`px-2 py-1 text-xs font-bold rounded-full ${getColor()}`}>{getFlame()} {score}</span>
                    <div className="absolute bottom-full mb-2 w-60 bg-[var(--color-dark)] text-white text-xs rounded py-1 px-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10 shadow-lg border border-gray-700">{reason || 'No reason provided.'}</div>
                </div>
            );
        };

        const stages: LeadStage[] = ['Caixa de Entrada', 'Qualificação', 'Oportunidade', 'Cliente (Ganho)', 'Perdido'];
        
        const renderKanbanView = () => (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                {stages.map(stage => (
                    <div key={stage} className="bg-[var(--color-secondary)] rounded-lg p-4">
                        <h3 className="font-bold text-lg mb-4">{stage} ({leads.filter(l => l.stage === stage).length})</h3>
                        <div className="space-y-3">
                            {leads.filter(l => l.stage === stage).map(lead => (
                                <div key={lead.id} className="p-3 bg-[var(--color-dark)] rounded-md shadow-lg">
                                    <p className="font-bold text-white">{lead.name}</p>
                                    <p className="text-sm text-gray-400">{lead.company}</p>
                                    <div className="flex justify-between items-center mt-2">
                                        <button onClick={() => setViewingLead(lead)} className="text-xs text-[var(--color-accent)] hover:underline">Ver Chat</button>
                                        {lead.isScoring ? <Spinner/> : <LeadScore score={lead.score} reason={lead.scoreReason} />}
                                        <button onClick={() => handleAIDrag(lead)} disabled={!!processingAI} className="text-gray-400 hover:text-white disabled:opacity-50">
                                           {processingAI === lead.id ? <Spinner/> : <SparklesIcon className="w-4 h-4" />}
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                ))}
            </div>
        );
        
        const renderListView = () => (
            <div className="bg-[var(--color-secondary)] rounded-lg overflow-hidden">
                <table className="min-w-full">
                    <thead className="bg-gray-700">
                        <tr>
                            <th className="px-4 py-2 text-left text-sm font-semibold text-gray-300">Name</th>
                            <th className="px-4 py-2 text-left text-sm font-semibold text-gray-300">Company</th>
                            <th className="px-4 py-2 text-left text-sm font-semibold text-gray-300">Stage</th>
                            <th className="px-4 py-2 text-left text-sm font-semibold text-gray-300">Lead Score</th>
                            <th className="px-4 py-2 text-left text-sm font-semibold text-gray-300">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-700">
                        {leads.map(lead => (
                            <tr key={lead.id}>
                                <td className="px-4 py-2 whitespace-nowrap">{lead.name}</td>
                                <td className="px-4 py-2 whitespace-nowrap">{lead.company}</td>
                                <td className="px-4 py-2 whitespace-nowrap">
                                    <select value={lead.stage} onChange={(e) => onUpdateLeadStage(lead.id, e.target.value as LeadStage)} className="w-full bg-transparent border-none p-2 rounded-md hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-[var(--color-accent)]">
                                        {stages.map(s => <option key={s} value={s} className="bg-gray-800 text-white">{s}</option>)}
                                    </select>
                                </td>
                                <td className="px-4 py-2 whitespace-nowrap">
                                    {lead.isScoring ? <Spinner/> : <LeadScore score={lead.score} reason={lead.scoreReason} />}
                                </td>
                                <td className="px-4 py-2 whitespace-nowrap">
                                    <button onClick={() => setViewingLead(lead)} className="text-[var(--color-accent)] hover:underline">View Chat</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        );

        return (
            <div>
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-3xl font-bold">Leads</h2>
                    <div className="flex items-center gap-2 p-1 bg-[var(--color-secondary)] rounded-lg">
                        <button onClick={() => setViewMode('kanban')} className={`px-3 py-1 rounded-md ${viewMode === 'kanban' ? 'bg-[var(--color-accent)]' : ''}`}><ViewGridIcon className="w-5 h-5"/></button>
                        <button onClick={() => setViewMode('list')} className={`px-3 py-1 rounded-md ${viewMode === 'list' ? 'bg-[var(--color-accent)]' : ''}`}><ViewListIcon className="w-5 h-5"/></button>
                    </div>
                </div>

                {viewMode === 'kanban' ? renderKanbanView() : renderListView()}
                
                {viewingLead && (
                    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
                        <div className="bg-[var(--color-secondary)] rounded-lg shadow-xl w-full max-w-2xl max-h-[80vh] flex flex-col">
                            <div className="p-4 border-b border-gray-700 flex justify-between items-center">
                                <h3 className="text-xl font-bold">Chat History: {viewingLead.name}</h3>
                                <button onClick={() => setViewingLead(null)} className="text-2xl">&times;</button>
                            </div>
                            <div className="flex-1 p-4 overflow-y-auto space-y-4">
                                {viewingLead.chatHistory.map((msg, index) => (
                                    <div key={index} className={`flex ${msg.isUser ? 'justify-end' : 'justify-start'}`}>
                                        <div className={`px-4 py-2 rounded-lg max-w-xs lg:max-w-md ${msg.isUser ? 'bg-[var(--color-accent)] text-white' : 'bg-gray-700 text-gray-200'}`}>
                                            {msg.text}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                )}
            </div>
        );
    };

    return (
        <div className="min-h-screen flex bg-[var(--color-dark)] text-[var(--color-light)]">
            <Sidebar />
            <main className="flex-1 p-4 md:p-8 overflow-y-auto">
                <MainContent/>
            </main>
        </div>
    );
};

export default App;